import React from 'react';

const Inventory = () => {
    return (
        <div>
            <h2>this is Inventory

            </h2>
        </div>
    );
};

export default Inventory;