import React from 'react';
import img from '../../images/giphy.gif'
import './PlaceOrder.css'

const PlaceOrder = () => {
    return (
        <div className='orderPlace'>
            <img src={img} alt="" />
        </div>
    );
};

export default PlaceOrder;